package entornos;

//	He cambiado el tema a dark aunque era el que estaba por defecto del sistema, y he añadido la fuente "Verdana" 
//	al Java Editor Text Font, le cambiado el tamaño a 12 y la he puesto en negrita.

public class Principal {
	public static void main(String[] args) {
 System.out.print("Bienvenido a Eclipse");
 System.out.println("Vamos a conocer el entorno de desarrollo");
	}
}